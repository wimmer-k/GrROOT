#ifdef __CINT__
#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;
#pragma extra_include "Fit.hh"
#pragma link C++ class S800Calc+;
#pragma link C++ class PAD+;
#pragma link C++ class PPAC+;
#pragma link C++ class IC+;
#pragma link C++ class TOF+;
#pragma link C++ class SCINT+;
#pragma link C++ class TRACK+;
#pragma link C++ class IITRACK+;
#pragma link C++ class HODO+;
#endif
