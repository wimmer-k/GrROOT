#ifdef __CINT__
#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;
#pragma link C++ class S800+;
#pragma link C++ class GTimeOfFlight+;
#pragma link C++ class GTrigger+;
#pragma link C++ class GScintillator+;
#pragma link C++ class GIonChamber+;
#pragma link C++ class GCrdc+;
#pragma link C++ class GTppac+;
#pragma link C++ class GLaBr;
#pragma link C++ class GHodoscope;
#pragma link C++ class GGalotte;
#endif
