#ifndef _GCC33_H
#define _GCC33_H

#ifdef DO_GCC33

#include <config.h>
#ifdef HAVE_STD_NAMESPACE
using namespace std;
#endif

#endif

#endif

// solving some namespace problems with gcc3-3 version 
