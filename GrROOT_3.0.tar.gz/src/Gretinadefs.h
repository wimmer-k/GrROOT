#define GRETINA_ID 1 //gretina identifier
#define MAX_SEGS 8              /* max. number of segments to take in events */
#define MAX_INTPTS (2*MAX_SEGS) /* max. number of interaction points */

#define MAXDETPOS 31 // modified this was 30 but used always as MAXDETPOS+1
#define MAXCRYSTALNO 4 // modified this was 3 but used always as MAXCRYSTALNO+1

