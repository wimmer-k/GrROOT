#define TRACE_ID 2 //gretina identifier
#define MAX_TDIFF_HIT 10
