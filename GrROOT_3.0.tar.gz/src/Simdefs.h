#define GRETINA_G4SIM_ID 11     /* ID for simulated gamma data */
#define MAX_SIM_GAMMAS 10       /* max. simulated gammas per event */
#define S800_PHYSDATA_ID 9      /* ID for S800 physics data */
